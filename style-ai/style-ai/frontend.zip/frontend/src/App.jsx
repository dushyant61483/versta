jsx
function App() {
  return (
    <h1
      style={{
        color: "red",
        backgroundColor: "white",
        padding: "50px",
        fontSize: "40px",
      }}
    >
      HELLO RASHA
    </h1>
  );
}

export default App;