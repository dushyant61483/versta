```jsx
import React, { useEffect, useRef, useState } from "react";

function CameraView({ onCameraReady, onCameraStop }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState("");

  const startCamera = async () => {
    try {
      setError("");

      if (!navigator.mediaDevices?.getUserMedia) {
        setError("Camera is not supported by this browser.");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
        },
        audio: false,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setIsActive(true);

      if (onCameraReady) {
        onCameraReady(stream);
      }
    } catch (err) {
      console.error("Camera error:", err);

      setError(
        "Unable to access the camera. Please allow camera permission and try again."
      );

      setIsActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        track.stop();
      });

      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setIsActive(false);

    if (onCameraStop) {
      onCameraStop();
    }
  };

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => {
          track.stop();
        });
      }
    };
  }, []);

  return (
    <div className="camera-view">

      {/* Camera Frame */}
      <div className="camera-frame">

        {isActive ? (
          <video
            ref={videoRef}
            className="camera-video"
            autoPlay
            playsInline
            muted
          />
        ) : (
          <div className="camera-placeholder">
            <div className="camera-icon">📷</div>

            <h3>Camera is Off</h3>

            <p>
              Enable your camera to start the virtual
              try-on experience.
            </p>

            <button
              type="button"
              className="start-camera-button"
              onClick={startCamera}
            >
              Enable Camera
            </button>
          </div>
        )}

        {/* Camera Status */}
        {isActive && (
          <div className="camera-status">
            <span className="status-dot" />
            Camera Active
          </div>
        )}
      </div>

      {/* Controls */}
      {isActive && (
        <div className="camera-controls">
          <button
            type="button"
            className="stop-camera-button"
            onClick={stopCamera}
          >
            Stop Camera
          </button>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="camera-error">
          {error}
        </div>
      )}
    </div>
  );
}

export default CameraView;
