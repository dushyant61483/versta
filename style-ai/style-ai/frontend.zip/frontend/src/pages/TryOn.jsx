jsx
import React, { useEffect, useRef, useState } from "react";

function TryOn() {
  const videoRef = useRef(null);
  const streamRef = useRef(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [selectedLook, setSelectedLook] = useState(0);

  const looks = [
    {
      name: "Urban Casual",
      top: "White Oversized Shirt",
      bottom: "Black Cargo Pants",
      shoes: "White Sneakers",
      image: "/images/outfit1.jpg",
    },
    {
      name: "Minimal Look",
      top: "White T-Shirt",
      bottom: "Blue Jeans",
      shoes: "White Sneakers",
      image: "/images/outfit2.jpg",
    },
    {
      name: "Streetwear",
      top: "Green Oversized Shirt",
      bottom: "Cargo Pants",
      shoes: "Black Sneakers",
      image: "/images/outfit3.jpg",
    },
  ];

  const currentLook = looks[selectedLook];

  // Start camera
  const startCamera = async () => {
    try {
      setCameraError("");

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
        },
        audio: false,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setCameraActive(true);
    } catch (error) {
      console.error("Camera error:", error);

      setCameraError(
        "Camera access was denied or is unavailable. Please allow camera permission and try again."
      );

      setCameraActive(false);
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        track.stop();
      });

      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setCameraActive(false);
  };

  // Stop camera when leaving page
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => {
          track.stop();
        });
      }
    };
  }, []);

  return (
    <main className="tryon-page">
      {/* Header */}
      <section className="tryon-header">
        <div>
          <span className="page-label">✦ VIRTUAL STYLIST</span>

          <h1>Try It On</h1>

          <p>
            See how your recommended outfit could look on you.
          </p>
        </div>
      </section>

      {/* Main Try-On Area */}
      <section className="tryon-container">

        {/* Camera */}
        <div className="camera-section">
          <div className="camera-frame">

            {cameraActive ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="camera-video"
              />
            ) : (
              <div className="camera-placeholder">
                <div className="camera-icon">📷</div>

                <h2>Start Virtual Try-On</h2>

                <p>
                  Turn on your camera to see your outfit
                  through the try-on experience.
                </p>

                <button
                  className="start-camera-button"
                  onClick={startCamera}
                >
                  Enable Camera
                </button>
              </div>
            )}

            {/* Camera Overlay */}
            {cameraActive && (
              <div className="camera-overlay">
                <div className="face-guide" />

                <div className="camera-status">
                  <span className="status-dot" />
                  Camera Active
                </div>
              </div>
            )}
          </div>

          {/* Camera Controls */}
          {cameraActive && (
            <div className="camera-controls">
              <button
                className="change-look-button"
                onClick={() =>
                  setSelectedLook(
                    (selectedLook + 1) % looks.length
                  )
                }
              >
                Change Look
              </button>

              <button
                className="stop-camera-button"
                onClick={stopCamera}
              >
                Stop Camera
              </button>
            </div>
          )}

          {/* Camera Error */}
          {cameraError && (
            <p className="camera-error">
              {cameraError}
            </p>
          )}
        </div>

        {/* Outfit Information */}
        <aside className="tryon-sidebar">

          <div className="selected-look-header">
            <span>SELECTED LOOK</span>

            <h2>{currentLook.name}</h2>
          </div>

          {/* Outfit Preview */}
          <div className="look-preview">
            <img
              src={currentLook.image}
              alt={currentLook.name}
            />
          </div>

          {/* Clothing Items */}
          <div className="look-items">
            <h3>Outfit</h3>

            <div className="look-item">
              <span>👕</span>
              <div>
                <small>Top</small>
                <strong>{currentLook.top}</strong>
              </div>
            </div>

            <div className="look-item">
              <span>👖</span>
              <div>
                <small>Bottom</small>
                <strong>{currentLook.bottom}</strong>
              </div>
            </div>

            <div className="look-item">
              <span>👟</span>
              <div>
                <small>Shoes</small>
                <strong>{currentLook.shoes}</strong>
              </div>
            </div>
          </div>

          {/* Styling Suggestions */}
          <div className="tryon-suggestions">
            <h3>Style Suggestions</h3>

            <div className="suggestion">
              <span>✓</span>
              <p>Color matches your selected style.</p>
            </div>

            <div className="suggestion">
              <span>✓</span>
              <p>Suitable for today's weather.</p>
            </div>

            <div className="suggestion">
              <span>✓</span>
              <p>Works well for a casual occasion.</p>
            </div>
          </div>

          {/* Action */}
          <button
            className="wear-look-button"
            onClick={() => {
              console.log("Selected look:", currentLook);
            }}
          >
            Select This Look
          </button>
        </aside>
      </section>

      {/* Look Selector */}
      <section className="look-selector">
        <div className="section-heading">
          <h2>Explore Looks</h2>

          <p>
            Switch between your recommended outfits.
          </p>
        </div>

        <div className="look-options">
          {looks.map((look, index) => (
            <button
              key={look.name}
              className={
                selectedLook === index
                  ? "look-option active"
                  : "look-option"
              }
              onClick={() => setSelectedLook(index)}
            >
              <img
                src={look.image}
                alt={look.name}
              />

              <span>{look.name}</span>
            </button>
          ))}
        </div>
      </section>
    </main>
  );
}

export default TryOn;