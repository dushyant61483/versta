jsx
import React, { useState } from "react";
import RecommendationCard from "../components/RecommendationCard";

function Recommendations() {
  const [selectedOccasion, setSelectedOccasion] = useState("College");

  const occasions = [
    "College",
    "Casual",
    "Party",
    "Wedding",
    "Interview",
    "Date",
  ];

  const recommendation = {
    title: "Urban Summer Look",
    subtitle: `Perfect for ${selectedOccasion.toLowerCase()} today`,

    image: "/images/outfit1.jpg",

    items: [
      "White Oversized Shirt",
      "Black Cargo Pants",
      "White Sneakers",
    ],

    styleScore: 94,
    weatherScore: 92,
    occasionScore: 96,
    styleCompatibility: 94,

    reason:
      "This lightweight combination suits today's warm weather, your casual streetwear style, and your selected occasion.",
  };

  const handleTryOn = (outfit) => {
    console.log("Opening virtual try-on:", outfit);

    // Later connect this to TryOn.jsx
  };

  const handleSelect = (outfit) => {
    console.log("Selected outfit:", outfit);

    // Later save the selected outfit
  };

  return (
    <main className="recommendations-page">

      {/* Page Header */}
      <section className="recommendations-header">
        <div>
          <span className="page-label">✦ AI STYLIST</span>

          <h1>What should you wear today?</h1>

          <p>
            Your personalized outfit based on your style,
            wardrobe, weather, and occasion.
          </p>
        </div>
      </section>

      {/* Weather Information */}
      <section className="weather-summary">
        <div className="weather-location">
          <span className="weather-icon">☁️</span>

          <div>
            <span className="weather-label">
              TODAY IN DELHI
            </span>

            <h3>29°C</h3>
          </div>
        </div>

        <div className="weather-details">
          <div>
            <span>Humidity</span>
            <strong>72%</strong>
          </div>

          <div>
            <span>Rain</span>
            <strong>60%</strong>
          </div>

          <div>
            <span>Condition</span>
            <strong>Cloudy</strong>
          </div>
        </div>
      </section>

      {/* Occasion Selection */}
      <section className="occasion-section">
        <div className="section-heading">
          <h2>What's the occasion?</h2>

          <p>
            Choose where you're going and we'll adjust
            your recommendation.
          </p>
        </div>

        <div className="occasion-options">
          {occasions.map((occasion) => (
            <button
              key={occasion}
              className={
                selectedOccasion === occasion
                  ? "occasion-button active"
                  : "occasion-button"
              }
              onClick={() => setSelectedOccasion(occasion)}
            >
              {occasion}
            </button>
          ))}
        </div>
      </section>

      {/* Main Recommendation */}
      <section className="main-recommendation">
        <RecommendationCard
          recommendation={recommendation}
          onTryOn={handleTryOn}
          onSelect={handleSelect}
        />
      </section>

      {/* Alternative Suggestions */}
      <section className="alternatives-section">
        <div className="section-heading">
          <h2>Other looks you might like</h2>

          <p>
            Try another combination from your wardrobe.
          </p>
        </div>

        <div className="alternative-grid">

          <article className="alternative-card">
            <div className="alternative-image">
              <img
                src="/images/outfit2.jpg"
                alt="Alternative outfit"
              />
            </div>

            <div className="alternative-content">
              <h3>Minimal Casual</h3>

              <p>
                White T-shirt · Blue Jeans · Sneakers
              </p>

              <span>Style Score: 89%</span>
            </div>
          </article>

          <article className="alternative-card">
            <div className="alternative-image">
              <img
                src="/images/outfit3.jpg"
                alt="Alternative outfit"
              />
            </div>

            <div className="alternative-content">
              <h3>Relaxed Streetwear</h3>

              <p>
                Green Shirt · Cargo Pants · Sneakers
              </p>

              <span>Style Score: 87%</span>
            </div>
          </article>

        </div>
      </section>

      {/* AI Tip */}
      <section className="styling-tip">
        <span>✦</span>

        <div>
          <h3>Stylist Tip</h3>

          <p>
            Carry an umbrella today because there is a
            60% chance of rain.
          </p>
        </div>
      </section>

    </main>
  );
}

export default Recommendations;